#include "ConfigLoader.h"
#include "JsonUtils.h"
#include <fstream>
#include <sstream>

bool ConfigLoader::LoadFromFile(const std::string& filepath, JsonValue& out) {
    std::ifstream file(filepath, std::ios::binary);
    if (!file) return false;
    std::stringstream buffer;
    buffer << file.rdbuf();
    return LoadFromString(buffer.str(), out);
}

bool ConfigLoader::LoadFromString(const std::string& content, JsonValue& out) {
    return JsonUtils::Parse(content, out);
}
