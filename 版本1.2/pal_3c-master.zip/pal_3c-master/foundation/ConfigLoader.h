#pragma once
#include <string>
#include "JsonValue.h"

class ConfigLoader {
public:
    static bool LoadFromFile(const std::string& filepath, JsonValue& out);
    static bool LoadFromString(const std::string& content, JsonValue& out);
};
