#pragma once
#include <string>
#include <vector>
#include "ISerializable.h"

class SaveLoadSystem {
public:
    static std::string SaveAll(const std::vector<ISerializable*>& modules);
    static bool LoadAll(const std::string& data, const std::vector<ISerializable*>& modules);
    static bool Validate(const std::string& data);
};
