#pragma once
#include <string>

class ISerializable {
public:
    virtual ~ISerializable() = default;
    virtual void Serialize(std::string& out) const = 0;
    virtual void Deserialize(const std::string& in) = 0;
};
