#include "SaveLoadSystem.h"
#include "JsonValue.h"
#include "JsonUtils.h"

std::string SaveLoadSystem::SaveAll(const std::vector<ISerializable*>& modules) {
    JsonValue root(JsonType::Object);
    for (size_t i = 0; i < modules.size(); ++i) {
        std::string moduleData;
        modules[i]->Serialize(moduleData);
        root.SetField("module_" + std::to_string(i), JsonValue(moduleData));
    }
    std::string out;
    JsonUtils::Write(root, out);
    return out;
}

bool SaveLoadSystem::LoadAll(const std::string& data, const std::vector<ISerializable*>& modules) {
    JsonValue root;
    if (!JsonUtils::Parse(data, root)) return false;
    for (size_t i = 0; i < modules.size(); ++i) {
        std::string key = "module_" + std::to_string(i);
        if (!root.HasField(key)) return false;
        modules[i]->Deserialize(root[key].AsString());
    }
    return true;
}

bool SaveLoadSystem::Validate(const std::string& data) {
    JsonValue root;
    return JsonUtils::Parse(data, root);
}
