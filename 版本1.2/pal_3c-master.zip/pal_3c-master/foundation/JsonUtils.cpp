#include "JsonUtils.h"
#include <sstream>
#include <iomanip>
#include <cmath>
#include <cstdio>
#include <cctype>

static std::string EscapeString(const std::string& s) {
    std::string out;
    for (unsigned char c : s) {
        switch (c) {
            case '"': out += "\\\""; break;
            case '\\': out += "\\\\"; break;
            case '\b': out += "\\b"; break;
            case '\f': out += "\\f"; break;
            case '\n': out += "\\n"; break;
            case '\r': out += "\\r"; break;
            case '\t': out += "\\t"; break;
            default:
                if (c < 0x20) {
                    char buf[7];
                    std::snprintf(buf, sizeof(buf), "\\u%04x", c);
                    out += buf;
                } else {
                    out += static_cast<char>(c);
                }
        }
    }
    return out;
}

static void WriteIndent(std::string& out, int count) {
    out.append(static_cast<size_t>(count), ' ');
}

static void WriteInternal(const JsonValue& val, std::string& out, int indent, int currentIndent) {
    switch (val.GetType()) {
        case JsonType::Null:
            out += "null";
            break;
        case JsonType::Bool:
            out += val.AsBool() ? "true" : "false";
            break;
        case JsonType::Number: {
            double d = val.AsDouble();
            if (std::isnan(d) || std::isinf(d)) {
                out += "null";
            } else if (d == std::floor(d) && d >= -2147483648.0 && d <= 2147483647.0) {
                out += std::to_string(static_cast<int>(d));
            } else {
                std::ostringstream oss;
                oss << std::setprecision(15) << d;
                out += oss.str();
            }
            break;
        }
        case JsonType::String:
            out += "\"";
            out += EscapeString(val.AsString());
            out += "\"";
            break;
        case JsonType::Array: {
            out += "[";
            size_t size = val.ArraySize();
            for (size_t i = 0; i < size; ++i) {
                if (i > 0) out += ",";
                if (indent >= 0) {
                    out += "\n";
                    WriteIndent(out, currentIndent + indent);
                }
                WriteInternal(val[i], out, indent, currentIndent + indent);
            }
            if (size > 0 && indent >= 0) {
                out += "\n";
                WriteIndent(out, currentIndent);
            }
            out += "]";
            break;
        }
        case JsonType::Object: {
            out += "{";
            auto keys = val.GetObjectKeys();
            for (size_t i = 0; i < keys.size(); ++i) {
                if (i > 0) out += ",";
                if (indent >= 0) {
                    out += "\n";
                    WriteIndent(out, currentIndent + indent);
                }
                out += "\"";
                out += EscapeString(keys[i]);
                out += "\"";
                if (indent >= 0) out += " ";
                out += ":";
                if (indent >= 0) out += " ";
                WriteInternal(val[keys[i]], out, indent, currentIndent + indent);
            }
            if (!keys.empty() && indent >= 0) {
                out += "\n";
                WriteIndent(out, currentIndent);
            }
            out += "}";
            break;
        }
    }
}

// ========== 重写后的 JSON 解析器（风格与 core/battle/JsonParser.h 一致） ==========
class JsonParser {
    const char* p = nullptr;

    void SkipWhitespace() {
        while (*p && (*p == ' ' || *p == '\t' || *p == '\n' || *p == '\r')) ++p;
    }

    bool ParseValue(JsonValue& out) {
        SkipWhitespace();
        if (*p == '"') return ParseString(out);
        if (*p == '{') return ParseObject(out);
        if (*p == '[') return ParseArray(out);
        if (*p == '-' || std::isdigit(static_cast<unsigned char>(*p))) return ParseNumber(out);
        if (*p == 't') return ParseTrue(out);
        if (*p == 'f') return ParseFalse(out);
        if (*p == 'n') return ParseNull(out);
        return false;
    }

    bool ParseString(JsonValue& out) {
        std::string str;
        ++p; // skip opening quote
        while (*p && *p != '"') {
            if (*p == '\\' && p[1]) {
                ++p;
                switch (*p) {
                    case '"': str += '"'; break;
                    case '\\': str += '\\'; break;
                    case '/': str += '/'; break;
                    case 'b': str += '\b'; break;
                    case 'f': str += '\f'; break;
                    case 'n': str += '\n'; break;
                    case 'r': str += '\r'; break;
                    case 't': str += '\t'; break;
                    case 'u': {
                        if (p[1] && p[2] && p[3] && p[4]) {
                            str += "\\u";
                            str += std::string(p + 1, 4);
                            p += 4;
                        }
                        break;
                    }
                    default: str += *p; break;
                }
            } else {
                str += *p;
            }
            ++p;
        }
        if (*p == '"') ++p;
        out = JsonValue(str);
        return true;
    }

    bool ParseNumber(JsonValue& out) {
        std::string numStr;
        if (*p == '-') { numStr += *p; ++p; }
        while (*p && std::isdigit(static_cast<unsigned char>(*p))) { numStr += *p; ++p; }
        if (*p == '.') {
            numStr += *p; ++p;
            while (*p && std::isdigit(static_cast<unsigned char>(*p))) { numStr += *p; ++p; }
        }
        if (numStr.empty() || numStr == "-") return false;
        try {
            double val = std::stod(numStr);
            out = JsonValue(val);
            return true;
        } catch (...) {
            return false;
        }
    }

    bool ParseObject(JsonValue& out) {
        out = JsonValue(JsonType::Object);
        ++p; // skip {
        while (true) {
            SkipWhitespace();
            if (*p == '}') { ++p; break; }
            JsonValue keyVal;
            if (!ParseString(keyVal)) return false;
            std::string key = keyVal.AsString();
            SkipWhitespace();
            if (*p == ':') ++p;
            JsonValue value;
            if (!ParseValue(value)) return false;
            out.SetField(key, value);
            SkipWhitespace();
            if (*p == ',') { ++p; continue; }
            if (*p == '}') { ++p; break; }
            if (*p == '\0') break;
        }
        return true;
    }

    bool ParseArray(JsonValue& out) {
        out = JsonValue(JsonType::Array);
        ++p; // skip [
        while (true) {
            SkipWhitespace();
            if (*p == ']') { ++p; break; }
            JsonValue element;
            if (!ParseValue(element)) return false;
            out.ArrayPush(element);
            SkipWhitespace();
            if (*p == ',') { ++p; continue; }
            if (*p == ']') { ++p; break; }
            if (*p == '\0') break;
        }
        return true;
    }

    bool ParseTrue(JsonValue& out) {
        if (p[0] == 't' && p[1] == 'r' && p[2] == 'u' && p[3] == 'e') {
            p += 4;
            out = JsonValue(true);
            return true;
        }
        return false;
    }

    bool ParseFalse(JsonValue& out) {
        if (p[0] == 'f' && p[1] == 'a' && p[2] == 'l' && p[3] == 's' && p[4] == 'e') {
            p += 5;
            out = JsonValue(false);
            return true;
        }
        return false;
    }

    bool ParseNull(JsonValue& out) {
        if (p[0] == 'n' && p[1] == 'u' && p[2] == 'l' && p[3] == 'l') {
            p += 4;
            out = JsonValue();
            return true;
        }
        return false;
    }

public:
    bool Parse(const std::string& text, JsonValue& out) {
        const char* start = text.c_str();
        // Skip UTF-8 BOM if present
        if (static_cast<unsigned char>(start[0]) == 0xEF &&
            static_cast<unsigned char>(start[1]) == 0xBB &&
            static_cast<unsigned char>(start[2]) == 0xBF) {
            start += 3;
        }
        p = start;
        SkipWhitespace();
        if (*p == '\0') return false;
        return ParseValue(out);
    }
};

bool JsonUtils::Parse(const std::string& json, JsonValue& out) {
    JsonParser parser;
    return parser.Parse(json, out);
}

bool JsonUtils::Write(const JsonValue& value, std::string& out, int indent) {
    out.clear();
    WriteInternal(value, out, indent, 0);
    return true;
}
