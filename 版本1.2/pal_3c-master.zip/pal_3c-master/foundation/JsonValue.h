#pragma once
#include <string>
#include <vector>
#include <unordered_map>

enum class JsonType { Null, Bool, Number, String, Array, Object };

class JsonValue {
public:
    JsonValue();
    explicit JsonValue(bool value);
    explicit JsonValue(int value);
    explicit JsonValue(double value);
    explicit JsonValue(const std::string& value);
    explicit JsonValue(const char* value);
    explicit JsonValue(JsonType type);

    JsonType GetType() const;

    bool AsBool() const;
    int AsInt() const;
    double AsDouble() const;
    std::string AsString() const;

    void SetNull();
    void SetBool(bool value);
    void SetNumber(double value);
    void SetString(const std::string& value);

    size_t ArraySize() const;
    JsonValue& operator[](size_t index);
    const JsonValue& operator[](size_t index) const;
    void ArrayPush(const JsonValue& value);
    void ArrayClear();

    bool HasField(const std::string& key) const;
    JsonValue& operator[](const std::string& key);
    const JsonValue& operator[](const std::string& key) const;
    void SetField(const std::string& key, const JsonValue& value);
    std::vector<std::string> GetObjectKeys() const;

private:
    JsonType type;
    bool boolValue;
    double numberValue;
    std::string stringValue;
    std::vector<JsonValue> arrayValue;
    std::unordered_map<std::string, JsonValue> objectValue;
};
