#pragma once
#include <string>
#include "JsonValue.h"

class JsonUtils {
public:
    static bool Parse(const std::string& json, JsonValue& out);
    static bool Write(const JsonValue& value, std::string& out, int indent = -1);
};
