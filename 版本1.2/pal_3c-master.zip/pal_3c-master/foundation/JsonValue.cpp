#include "JsonValue.h"

JsonValue::JsonValue() : type(JsonType::Null), boolValue(false), numberValue(0) {}
JsonValue::JsonValue(bool value) : type(JsonType::Bool), boolValue(value), numberValue(0) {}
JsonValue::JsonValue(int value) : type(JsonType::Number), boolValue(false), numberValue(value) {}
JsonValue::JsonValue(double value) : type(JsonType::Number), boolValue(false), numberValue(value) {}
JsonValue::JsonValue(const std::string& value) : type(JsonType::String), boolValue(false), numberValue(0), stringValue(value) {}
JsonValue::JsonValue(const char* value) : JsonValue(std::string(value)) {}
JsonValue::JsonValue(JsonType t) : type(t), boolValue(false), numberValue(0) {}

JsonType JsonValue::GetType() const { return type; }

bool JsonValue::AsBool() const { return (type == JsonType::Bool) ? boolValue : false; }
int JsonValue::AsInt() const { return (type == JsonType::Number) ? static_cast<int>(numberValue) : 0; }
double JsonValue::AsDouble() const { return (type == JsonType::Number) ? numberValue : 0.0; }
std::string JsonValue::AsString() const { return (type == JsonType::String) ? stringValue : ""; }

void JsonValue::SetNull() { type = JsonType::Null; }
void JsonValue::SetBool(bool value) { type = JsonType::Bool; boolValue = value; }
void JsonValue::SetNumber(double value) { type = JsonType::Number; numberValue = value; }
void JsonValue::SetString(const std::string& value) { type = JsonType::String; stringValue = value; }

size_t JsonValue::ArraySize() const { return (type == JsonType::Array) ? arrayValue.size() : 0; }

JsonValue& JsonValue::operator[](size_t index) {
    if (type == JsonType::Array && index < arrayValue.size()) return arrayValue[index];
    static JsonValue nullValue;
    return nullValue;
}

const JsonValue& JsonValue::operator[](size_t index) const {
    if (type == JsonType::Array && index < arrayValue.size()) return arrayValue[index];
    static JsonValue nullValue;
    return nullValue;
}

void JsonValue::ArrayPush(const JsonValue& value) {
    if (type != JsonType::Array) { type = JsonType::Array; }
    arrayValue.push_back(value);
}

void JsonValue::ArrayClear() {
    if (type == JsonType::Array) arrayValue.clear();
}

bool JsonValue::HasField(const std::string& key) const {
    return (type == JsonType::Object) && (objectValue.find(key) != objectValue.end());
}

JsonValue& JsonValue::operator[](const std::string& key) {
    if (type != JsonType::Object) { type = JsonType::Object; }
    return objectValue[key];
}

const JsonValue& JsonValue::operator[](const std::string& key) const {
    static JsonValue nullValue;
    if (type != JsonType::Object) return nullValue;
    auto it = objectValue.find(key);
    return (it != objectValue.end()) ? it->second : nullValue;
}

void JsonValue::SetField(const std::string& key, const JsonValue& value) {
    if (type != JsonType::Object) { type = JsonType::Object; }
    objectValue[key] = value;
}

std::vector<std::string> JsonValue::GetObjectKeys() const {
    std::vector<std::string> result;
    if (type == JsonType::Object) {
        for (const auto& pair : objectValue) {
            result.push_back(pair.first);
        }
    }
    return result;
}
